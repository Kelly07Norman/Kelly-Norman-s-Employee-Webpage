<?php


?>

<html>

<head>

<body>

    <div>
        WELCOME TO THE EMPLOYEE INFORMATION MANAGEMENT SYSTEM
    </div>
    <br /> <br />
    <div>
        <a href="login.php"> Login</a> | <a href="register.php"> Register</a>
    </div>

</body>

</html>