<?php


$databaseHost     = 'localhost';
$databaseName     = 'register_login_db';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
